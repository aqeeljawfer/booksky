// Select popup elements
var popupoverlay = document.querySelector(".popup-overlay");
var popupbox = document.querySelector(".popup-box");
var popupbutton = document.getElementById("add-popup-button");

// Open popup
popupbutton.addEventListener("click", function () {
  popupoverlay.style.display = "block";
  popupbox.style.display = "block";
});

// Cancel popup
var cancelpopup = document.getElementById("cancel-popup");
cancelpopup.addEventListener("click", function (event) {
  event.preventDefault();
  popupoverlay.style.display = "none";
  popupbox.style.display = "none";
});

// Select form inputs
var container = document.querySelector(".container");
var addbook = document.getElementById("add-book");
var booktitleinput = document.getElementById("book-title-input");
var bookauthorinput = document.getElementById("book-author-input");
var bookdescinput = document.getElementById("book-description-input");

// Add new book
addbook.addEventListener("click", function () {
  var title = booktitleinput.value.trim();
  var author = bookauthorinput.value.trim();
  var desc = bookdescinput.value.trim();

  if (title === "" || author === "" || desc === "") {
    alert("Please fill in all fields");
    return;
  }

  var div = document.createElement("div");
  div.setAttribute("class", "book-container");
  div.innerHTML = `
        <h2>${title}</h2>
        <h5>${author}</h5>
        <p>${desc}</p>
        <button class="delete-book">Delete</button>
    `;

  container.append(div);

  // Clear inputs
  booktitleinput.value = "";
  bookauthorinput.value = "";
  bookdescinput.value = "";

  // Close popup
  popupoverlay.style.display = "none";
  popupbox.style.display = "none";
});

// Delete book (event delegation)
container.addEventListener("click", function (e) {
  if (e.target.classList.contains("delete-book")) {
    e.target.parentElement.remove();
  }
});
